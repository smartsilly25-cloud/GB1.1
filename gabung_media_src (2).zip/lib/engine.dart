import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:path_provider/path_provider.dart';
import 'comic.dart';
import 'gutter.dart';
import 'models.dart';

const kFps = 30;
const _swEnc = ['-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '24', '-pix_fmt', 'yuv420p'];

class Info {
  final double dur, w, h;
  Info(this.dur, this.w, this.h);
}

// ===================== WINDOWS: ffmpeg.exe / ffprobe.exe =====================

Process? _proc;
bool _cancelled = false;

/// Cari ffmpeg.exe / ffprobe.exe: folder `ffmpeg\` di samping aplikasi,
/// lalu di samping aplikasi, lalu PATH sistem.
String _bin(String name) {
  final base = File(Platform.resolvedExecutable).parent.path;
  final sep = Platform.pathSeparator;
  for (final p in ['$base${sep}ffmpeg$sep$name.exe', '$base$sep$name.exe']) {
    if (File(p).existsSync()) return p;
  }
  return name; // coba dari PATH
}

Exception _notFound(String name) => Exception(
    '$name.exe tidak ditemukan. Letakkan ffmpeg.exe dan ffprobe.exe di folder "ffmpeg" '
    'di samping aplikasi, atau tambahkan ke PATH Windows.');

Future<Info> _probeWin(String path) async {
  try {
    final r = await Process.run(
      _bin('ffprobe'),
      ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', path],
      stdoutEncoding: const Utf8Codec(allowMalformed: true),
      stderrEncoding: const Utf8Codec(allowMalformed: true),
    );
    if (r.exitCode != 0) return Info(0, 0, 0);
    final j = jsonDecode(r.stdout as String) as Map<String, dynamic>;
    final dur = double.tryParse('${(j['format'] as Map?)?['duration']}') ?? 0;
    double w = 0, h = 0;
    for (final st in (j['streams'] as List? ?? const [])) {
      if (st is! Map || st['codec_type'] != 'video') continue;
      w = double.tryParse('${st['width']}') ?? 0;
      h = double.tryParse('${st['height']}') ?? 0;
      var rot = 0.0;
      final sd = st['side_data_list'];
      if (sd is List) {
        for (final e in sd) {
          if (e is Map && e['rotation'] != null) rot = double.tryParse('${e['rotation']}') ?? rot;
        }
      }
      final tags = st['tags'];
      if (tags is Map && tags['rotate'] != null) rot = double.tryParse('${tags['rotate']}') ?? rot;
      if (rot.abs() % 180 == 90) {
        final t = w;
        w = h;
        h = t;
      }
      break;
    }
    return Info(dur, w, h);
  } catch (_) {
    return Info(0, 0, 0);
  }
}

Future<void> _runWin(List<String> args) async {
  if (_cancelled) throw Exception('Dibatalkan');
  final Process p;
  try {
    p = await Process.start(_bin('ffmpeg'), ['-hide_banner', '-nostdin', '-loglevel', 'error', ...args]);
  } on ProcessException {
    throw _notFound('ffmpeg');
  }
  _proc = p;
  p.stdout.drain();
  final err = StringBuffer();
  final errDone = p.stderr.transform(const Utf8Decoder(allowMalformed: true)).forEach(err.write);
  final code = await p.exitCode;
  await errDone;
  _proc = null;
  if (_cancelled) throw Exception('Dibatalkan');
  if (code == 0) return;
  final out = err.toString();
  throw Exception(out.length > 700 ? out.substring(out.length - 700) : out);
}

/// Windows: coba encoder GPU (NVIDIA -> Intel -> AMD), kalau tidak ada pakai x264.
Future<List<String>> _pickEncoderWin(Directory dir, int w, int h) async {
  for (final codec in ['h264_nvenc', 'h264_qsv', 'h264_amf']) {
    try {
      final r = await Process.run(_bin('ffmpeg'), [
        '-hide_banner', '-nostdin', '-loglevel', 'error', '-y',
        '-f', 'lavfi', '-i', 'color=c=black:s=320x240:r=30:d=0.5',
        '-c:v', codec, '-b:v', '2M', '-pix_fmt', 'yuv420p',
        '${dir.path}${Platform.pathSeparator}enc_test.mp4'
      ]);
      if (r.exitCode == 0) {
        final bps = (w * h * kFps * 0.12).round();
        return ['-c:v', codec, '-b:v', '$bps', '-pix_fmt', 'yuv420p'];
      }
    } catch (_) {}
  }
  return _swEnc;
}

/// Simpan hasil di folder yang sama dengan aplikasi (gabung_media.exe).
/// Kalau folder itu tidak bisa ditulis, simpan ke folder Videos pengguna.
Future<String> _saveWin(String result) async {
  final name = result.split(RegExp(r'[\\/]')).last;
  final appDir = File(Platform.resolvedExecutable).parent;
  try {
    final dest = '${appDir.path}${Platform.pathSeparator}$name';
    File(result).copySync(dest);
    return dest;
  } catch (_) {}
  final home = Platform.environment['USERPROFILE'];
  Directory? target;
  if (home != null) target = Directory('$home${Platform.pathSeparator}Videos');
  if (target == null || !target.existsSync()) {
    try {
      target = await getDownloadsDirectory();
    } catch (_) {}
  }
  if (target == null) return result;
  if (!target.existsSync()) target.createSync(recursive: true);
  final dest = '${target.path}${Platform.pathSeparator}$name';
  File(result).copySync(dest);
  return dest;
}

// ===================== PROBE / RUN (pilih platform) =====================

Future<Info> probeInfo(String path) => _probeWin(path);

Future<double> probeDuration(String path) async => (await probeInfo(path)).dur;

Future<void> cancelRender() async {
  _cancelled = true;
  _proc?.kill();
}

Future<void> _run(List<String> args) => _runWin(args);

Future<List<String>> _pickEncoder(Directory dir, int w, int h) => _pickEncoderWin(dir, w, h);

// ===================== RENDER (halaman komik) =====================

class _Page {
  final List<Panel> panels;
  final String gutter;
  final List<String?> masks; // masker untuk panel miring (null = panel persegi)
  _Page(this.panels, this.gutter, this.masks);
}

Future<String> renderVideo({
  required Fmt fmt,
  required List<Media> items,
  required Bg bg,
  required List<Sound> sounds,
  required double total,
  required bool auto,
  required double manualDur,
  double pause = 5,
  required Opts opts,
  required void Function(String msg, double v) onProgress,
}) async {
  _cancelled = false;
  final cf = scaleFmt(fmt, kQuality[opts.quality]);
  final frames = buildFrames(items);
  final pz = pause < 0 ? 0.0 : pause;
  final u = auto ? max(0.5, (total - pz * frames.length) / items.length) : manualDur;
  final t = u * items.length + pz * frames.length;
  final tmp = await getTemporaryDirectory();
  final dir = Directory('${tmp.path}${Platform.pathSeparator}render');
  if (dir.existsSync()) dir.deleteSync(recursive: true);
  dir.createSync(recursive: true);
  final d = dir.path.replaceAll('\\', '/');
  final w = cf.w, h = cf.h;
  String s3(double v) => v.toStringAsFixed(3);

  final bgImg = bg.image != null ? await loadUiImage(bg.image!) : null;
  final pages = <String, _Page>{};

  Future<_Page> pageFor(List<Media> g, int fi) async {
    final v = effVariant(g, fi);
    final key = '${g.first.multi}:$v:${g.first.zoom.toStringAsFixed(2)}';
    final hit = pages[key];
    if (hit != null) return hit;
    final panels = comicLayout(cf, g, v, bg);
    final id = pages.length;
    final gut = '$d/gut$id.png';
    await renderGutterPng(w, h, panels, bg, bgImg, gut);
    final masks = <String?>[];
    for (var k = 0; k < panels.length; k++) {
      if (panels[k].isRect) {
        masks.add(null);
        continue;
      }
      final mp = '$d/mask${id}_$k.png';
      await renderMaskPng(panels[k], mp);
      masks.add(mp);
    }
    return pages[key] = _Page(panels, gut, masks);
  }

  Future<List<String>> makeSegs(List<String> enc) async {
    final segs = <String>[];
    for (var f = 0; f < frames.length; f++) {
      onProgress('Halaman ${f + 1} dari ${frames.length}', f / (frames.length + 1));
      final g = frames[f];
      final page = await pageFor(g, f);
      final dd = u * g.length + pz;
      final args = <String>['-y', '-f', 'lavfi', '-t', s3(dd), '-i', 'color=c=black:s=${w}x$h:r=$kFps'];
      for (final m in g) {
        if (m.isVideo) {
          args.addAll(['-i', m.path]);
        } else {
          args.addAll(['-framerate', '$kFps', '-i', m.path]);
        }
      }
      var inputs = g.length + 1; // jumlah input sejauh ini (0 = dasar hitam)
      final gutterIdx = inputs++;
      args.addAll(['-loop', '1', '-framerate', '$kFps', '-t', s3(dd), '-i', page.gutter]);

      final fc = StringBuffer('[0:v]setsar=1,format=yuv420p[bg0];');
      var prev = 'bg0';
      for (var k = 0; k < g.length && k < page.panels.length; k++) {
        final m = g[k], p = page.panels[k];
        final ts = k * u;
        final r = (m.isVideo && m.dur > 0) ? u / m.dur : 1.0;
        final rem = dd - ts - u;
        final fi = min(0.5, u / 4), fo = min(0.5, dd / 8);
        final cover = useCover(opts, m, p);
        final String fit, pos;
        String? mask;
        var pre = ''; // graf awal (mode utuh + blur) yang menghasilkan [a$k]
        if (cover) {
          final c = p.cell;
          fit = 'scale=${c.w}:${c.h}:force_original_aspect_ratio=increase,crop=${c.w}:${c.h}';
          pos = 'x=${c.l}:y=${c.t}';
          mask = page.masks[k];
          if (useBlur(opts)) {
            final asp = (m.w > 0 && m.h > 0) ? m.w / m.h : p.box.width / p.box.height;
            final fr = p.fit(asp);
            final fw = ev(fr.width), fh = ev(fr.height);
            final fx = (fr.left - c.l).round(), fy = (fr.top - c.t).round();
            pre = '[${k + 1}:v]split=2[s1_$k][s2_$k];'
                '[s1_$k]$fit,scale=trunc(iw/20)*2:trunc(ih/20)*2,boxblur=3:2,scale=${c.w}:${c.h}:flags=bicubic,setsar=1,format=yuv420p[b_$k];'
                '[s2_$k]scale=$fw:$fh:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1[f_$k];'
                '[b_$k][f_$k]overlay=x=$fx:y=$fy:eof_action=pass,format=yuv420p[a$k];';
          }
        } else {
          final asp = (m.w > 0 && m.h > 0) ? m.w / m.h : p.box.width / p.box.height;
          final fr = p.fit(asp);
          fit = 'scale=${ev(fr.width)}:${ev(fr.height)}:force_original_aspect_ratio=decrease:force_divisible_by=2';
          pos = 'x=${fr.center.dx.toStringAsFixed(1)}-w/2:y=${fr.center.dy.toStringAsFixed(1)}-h/2';
        }
        final fades = 'fade=t=in:st=${s3(ts)}:d=${s3(fi)}:alpha=1,fade=t=out:st=${s3(dd - fo)}:d=${s3(fo)}:alpha=1';
        final hold = rem > 0.01 ? 'tpad=stop_mode=clone:stop_duration=${s3(rem)},' : '';
        final src = '[${k + 1}:v]';
        if (pre.isNotEmpty || mask != null) {
          fc.write(pre.isNotEmpty ? pre : '$src$fit,setsar=1,format=yuv420p[a$k];');
          var amerge = '';
          if (mask != null) {
            final mi = inputs++;
            args.addAll(['-framerate', '$kFps', '-i', mask]);
            amerge = '[a$k][$mi:v]alphamerge,';
          } else {
            amerge = '[a$k]';
          }
          if (m.isVideo) {
            fc.write('${amerge}setpts=(PTS-STARTPTS)*${r.toStringAsFixed(5)}+${s3(ts)}/TB,'
                'fps=$kFps,format=yuva420p,$hold$fades[m$k];');
          } else {
            fc.write('${amerge}format=yuva420p,tpad=stop_mode=clone:stop_duration=${s3(dd)},'
                'setpts=PTS-STARTPTS+${s3(ts)}/TB,fps=$kFps,$fades[m$k];');
          }
        } else if (m.isVideo) {
          fc.write('${src}setpts=(PTS-STARTPTS)*${r.toStringAsFixed(5)}+${s3(ts)}/TB,fps=$kFps,$fit,setsar=1,'
              'format=yuva420p,$hold$fades[m$k];');
        } else {
          fc.write('$src$fit,setsar=1,format=yuva420p,tpad=stop_mode=clone:stop_duration=${s3(dd)},'
              'setpts=PTS-STARTPTS+${s3(ts)}/TB,fps=$kFps,$fades[m$k];');
        }
        fc.write('[$prev][m$k]overlay=$pos:eof_action=pass[o$k];');
        prev = 'o$k';
      }
      fc.write('[$prev][$gutterIdx:v]overlay=0:0[outv]');
      final out = '$d/seg$f.mp4';
      args.addAll(['-filter_complex', fc.toString(), '-map', '[outv]', '-t', s3(dd), '-r', '$kFps', '-an', ...enc, out]);
      await _run(args);
      segs.add(out);
    }
    return segs;
  }

  onProgress('Menyiapkan encoder…', 0);
  final enc = await _pickEncoder(dir, w, h);
  List<String> segs;
  try {
    segs = await makeSegs(enc);
  } catch (e) {
    if (e.toString().contains('Dibatalkan') || enc.contains('libx264')) rethrow;
    segs = await makeSegs(_swEnc);
  }

  onProgress('Menggabungkan halaman…', frames.length / (frames.length + 1));
  File('${dir.path}${Platform.pathSeparator}list.txt')
      .writeAsStringSync(segs.map((p) => "file '$p'").join('\n'));
  final joined = '$d/joined.mp4';
  await _run(['-y', '-f', 'concat', '-safe', '0', '-i', '$d/list.txt', '-c', 'copy', joined]);

  final result = '${tmp.path}${Platform.pathSeparator}Gabung_${DateTime.now().millisecondsSinceEpoch}.mp4';
  final used = sounds.where((s) => min(s.stop, t) - s.start > 0).toList();
  if (used.isEmpty) {
    File(joined).copySync(result);
  } else {
    onProgress('Memasang suara…', 0.97);
    final args = <String>['-y', '-i', joined];
    final fc = StringBuffer();
    for (var k = 0; k < used.length; k++) {
      final s = used[k];
      args.addAll(['-i', s.path]);
      final len = min(s.stop, t) - s.start;
      final ms = (s.start * 1000).round();
      fc.write('[${k + 1}:a]atrim=0:${s3(len)},asetpts=PTS-STARTPTS,volume=${s.volume.toStringAsFixed(2)},adelay=$ms|$ms[a$k];');
    }
    for (var k = 0; k < used.length; k++) {
      fc.write('[a$k]');
    }
    fc.write('amix=inputs=${used.length}:duration=longest:normalize=0[aout]');
    args.addAll(['-filter_complex', fc.toString(), '-map', '0:v', '-map', '[aout]',
      '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-t', s3(t), result]);
    await _run(args);
  }

  final finalPath = await _saveWin(result);
  onProgress('Selesai', 1);
  return finalPath;
}
