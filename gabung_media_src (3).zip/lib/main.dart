import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'comic.dart';
import 'engine.dart';
import 'gutter.dart';
import 'models.dart';

const orange = Color(0xFFFF6B3D);
const grey = TextStyle(color: Color(0xFFB0B0B0), fontSize: 13);

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Gabung Media',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorSchemeSeed: orange,
          scaffoldBackgroundColor: const Color(0xFF121212),
        ),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int step = 0;
  Fmt? fmt;
  final items = <Media>[];
  final bg = Bg();
  final opts = Opts();
  final sounds = <Sound>[];
  bool auto = true;
  double total = 60;
  double manualDur = 5;
  double pause = 5; // jeda antar slide (detik)
  bool busy = false;
  String status = '';
  double prog = 0;
  ui.Image? bgImg; // gambar latar yang sudah dibaca (untuk pratinjau)
  int pv = 0; // halaman pratinjau
  int _rev = 0; // memaksa kolom waktu dibuat ulang saat nilai diubah dari luar

  List<List<Media>> get frames => buildFrames(items);
  double get unit => auto ? max(0.5, (total - pause * frames.length) / max(1, items.length)) : manualDur;

  // ---------- aksi ----------
  Future<void> addMedia() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'mp4', 'mov', 'mkv', 'webm', '3gp', 'avi', 'm4v'],
      allowMultiple: true,
    );
    if (r == null) return;
    for (final f in r.files) {
      final p = f.path;
      if (p == null || items.length >= kMaxItems) continue;
      final v = isVideoPath(p);
      final info = await probeInfo(p);
      final m = Media(p, v, v ? info.dur : 0);
      m.w = info.w;
      m.h = info.h;
      items.add(m);
    }
    if (mounted) setState(() {});
  }

  Future<void> addSound() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio, allowMultiple: true);
    if (r == null) return;
    for (final f in r.files) {
      if (f.path == null) continue;
      sounds.add(Sound(f.path!, f.name, await probeDuration(f.path!)));
    }
    if (sounds.isNotEmpty) total = sounds.map((s) => s.stop).reduce(max);
    if (mounted) setState(() => _rev++);
  }

  Future<void> pickBg() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif'],
    );
    final p = r?.files.single.path;
    if (p == null) return;
    final im = await loadUiImage(p);
    if (!mounted) return;
    if (im == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gambar latar tidak bisa dibaca. Coba format JPG atau PNG.')));
      return;
    }
    setState(() {
      bg.image = p;
      bgImg = im;
    });
  }

  Future<void> _export() async {
    setState(() {
      busy = true;
      status = 'Menyiapkan…';
      prog = 0;
    });
    String msg;
    try {
      final outPath = await renderVideo(
        fmt: fmt!,
        items: items,
        bg: bg,
        sounds: sounds,
        total: total,
        auto: auto,
        manualDur: manualDur,
        pause: pause,
        opts: opts,
        onProgress: (m, v) {
          if (mounted) setState(() {
            status = m;
            prog = v;
          });
        },
      );
      msg = 'Selesai! Video tersimpan di:\n$outPath';
    } catch (e) {
      msg = 'Gagal: $e';
    }
    if (!mounted) return;
    setState(() => busy = false);
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        content: SingleChildScrollView(child: SelectableText(msg)),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ),
    );
  }

  bool get _canNext => switch (step) { 0 => fmt != null, 1 => items.isNotEmpty, _ => true };

  void _next() => step < 3 ? setState(() => step++) : _export();

  // ---------- kerangka ----------
  @override
  Widget build(BuildContext context) {
    const titles = ['Pilih Format', 'Muat Foto / Video', 'Latar & Gaya Frame', 'Suara & Durasi'];
    return Scaffold(
      appBar: AppBar(title: Text('${step + 1}/4  ${titles[step]}')),
      body: busy ? _busy() : _body(),
      bottomNavigationBar: busy
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  if (step > 0) ...[
                    Expanded(child: OutlinedButton(onPressed: () => setState(() => step--), child: const Text('Kembali'))),
                    const SizedBox(width: 12),
                  ],
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: _canNext ? _next : null,
                      child: Text(step == 3 ? 'Gabungkan & Ekspor' : 'Lanjut'),
                    ),
                  ),
                ]),
              ),
            ),
    );
  }

  Widget _body() => switch (step) {
        0 => _formatStep(),
        1 => _mediaStep(),
        2 => _bgStep(),
        _ => _soundStep(),
      };

  Widget _busy() => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            LinearProgressIndicator(value: prog),
            const SizedBox(height: 16),
            Text(status),
            const SizedBox(height: 24),
            OutlinedButton(onPressed: cancelRender, child: const Text('Batalkan')),
          ]),
        ),
      );

  // ---------- 1: format ----------
  Widget _formatStep() => Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            for (final f in formats)
              InkWell(
                onTap: () => setState(() => fmt = f),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(width: 2, color: fmt == f ? orange : const Color(0xFF333333)),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SizedBox(
                      width: 90,
                      height: 90,
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: f.w / f.h,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2, color: fmt == f ? orange : Colors.grey),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(f.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
          ],
        ),
      );

  // ---------- 2: muat media ----------
  Widget _mediaStep() {
    final leads = <int, int>{}; // indeks media -> nomor halaman
    var i = 0, fi = 0;
    while (i < items.length) {
      leads[i] = fi++;
      i += max(1, items[i].multi);
    }
    return Column(children: [
      Expanded(
        child: ReorderableListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          onReorder: (a, b) => setState(() {
            if (b > a) b--;
            items.insert(b, items.removeAt(a));
          }),
          itemBuilder: (c, idx) => Card(key: items[idx].key, child: _mediaTile(idx, items[idx], leads[idx])),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        child: OutlinedButton.icon(
          onPressed: items.length >= kMaxItems ? null : addMedia,
          icon: const Icon(Icons.add),
          label: Text('Tambah foto / video (${items.length}/$kMaxItems)'),
        ),
      ),
    ]);
  }

  Widget _layoutThumb(List<Media> g, int fi) {
    final f = fmt!;
    final panels = comicLayout(f, g, effVariant(g, fi), bg);
    return SizedBox(
      height: 56,
      child: AspectRatio(
        aspectRatio: f.w / f.h,
        child: CustomPaint(painter: LayoutThumbPainter(f.w.toDouble(), f.h.toDouble(), panels, orange)),
      ),
    );
  }

  Widget _mediaTile(int idx, Media m, int? fi) => Padding(
        padding: const EdgeInsets.all(10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${idx + 1}', style: const TextStyle(color: orange, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(width: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(width: 56, height: 56, child: _thumb(m, cover: true)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.path.split(RegExp(r'[\\/]')).last, maxLines: 1, overflow: TextOverflow.ellipsis),
              if (fi == null)
                const Text('Ikut frame multi di atasnya', style: grey)
              else ...[
                Wrap(spacing: 6, children: [
                  for (final n in const [1, 2, 3, 4, 5, 6, 8])
                    ChoiceChip(
                      label: Text('${n}x'),
                      selected: m.multi == n,
                      onSelected: (_) => setState(() {
                        m.multi = n;
                        m.variant = -1;
                      }),
                    ),
                ]),
                const SizedBox(height: 6),
                Row(children: [
                  _layoutThumb(frames[fi], fi),
                  const SizedBox(width: 8),
                  if (bg.comic)
                    TextButton.icon(
                      onPressed: () => setState(() => m.variant = effVariant(frames[fi], fi) + 1),
                      icon: const Icon(Icons.shuffle, size: 18),
                      label: const Text('Ganti susunan'),
                    ),
                ]),
                if (m.multi == 1)
                  Row(children: [
                    const Text('Ukuran', style: grey),
                    Expanded(child: Slider(value: m.zoom.clamp(0.5, 1.0).toDouble(), min: 0.5, max: 1, onChanged: (v) => setState(() => m.zoom = v))),
                    Text('${(m.zoom * 100).round()}%', style: grey),
                  ]),
              ],
            ]),
          ),
          IconButton(onPressed: () => setState(() => items.remove(m)), icon: const Icon(Icons.close)),
        ]),
      );

  Widget _thumb(Media m, {bool cover = false}) => m.isVideo
      ? Container(color: Colors.blueGrey.shade800, child: const Icon(Icons.movie))
      : Image.file(File(m.path), fit: cover ? BoxFit.cover : BoxFit.contain, cacheWidth: 400);

  // ---------- 3: latar & gaya ----------
  Widget _bgStep() {
    final f = fmt!;
    final fr = frames;
    final pi = pv.clamp(0, fr.length - 1);
    const colors = [
      0xFFFFFFFF, 0xFFF5E9D0, 0xFF9E9E9E, 0xFF111111, 0xFFE8501F, 0xFFFFC107,
      0xFF2E7D32, 0xFF1E3A8A, 0xFF6A1B9A, 0xFFD81B60, 0xFF00897B, 0xFF5D4037,
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 380),
          child: AspectRatio(aspectRatio: f.w / f.h, child: _preview(fr[pi], pi)),
        ),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(onPressed: pi > 0 ? () => setState(() => pv = pi - 1) : null, icon: const Icon(Icons.chevron_left)),
        Text('Halaman ${pi + 1} / ${fr.length}', style: grey),
        IconButton(onPressed: pi < fr.length - 1 ? () => setState(() => pv = pi + 1) : null, icon: const Icon(Icons.chevron_right)),
      ]),
      const SizedBox(height: 8),
      const Text('Gaya frame', style: grey),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: true, label: Text('Komik (miring)')),
          ButtonSegment(value: false, label: Text('Kotak rapi')),
        ],
        selected: {bg.comic},
        onSelectionChanged: (v) => setState(() => bg.comic = v.first),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Sesuaikan frame dengan bentuk foto'),
        subtitle: const Text('Ukuran & susunan frame dihitung otomatis agar foto hampir tidak terpotong', style: grey),
        value: bg.fitLayout,
        onChanged: (v) => setState(() => bg.fitLayout = v),
      ),
      const SizedBox(height: 8),
      const Text('Latar halaman', style: grey),
      const SizedBox(height: 8),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final c in colors)
          GestureDetector(
            onTap: () => setState(() {
              bg.color = c;
              bg.image = null;
              bgImg = null;
            }),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Color(c),
                shape: BoxShape.circle,
                border: Border.all(width: 3, color: bg.image == null && bg.color == c ? orange : Colors.grey.shade700),
              ),
            ),
          ),
      ]),
      const SizedBox(height: 10),
      TextField(
        decoration: const InputDecoration(
          labelText: 'Warna sendiri (hex 6 digit, mis. FF8800) lalu Enter',
          isDense: true,
          border: OutlineInputBorder(),
        ),
        onSubmitted: (t) {
          final s = t.replaceAll('#', '').trim();
          final v = int.tryParse(s, radix: 16);
          if (v != null && s.length == 6) {
            setState(() {
              bg.color = 0xFF000000 | v;
              bg.image = null;
              bgImg = null;
            });
          }
        },
      ),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: pickBg,
            icon: const Icon(Icons.image),
            label: const Text('Muat latar dari penyimpanan'),
          ),
        ),
        if (bg.image != null) ...[
          const SizedBox(width: 8),
          IconButton(
            tooltip: 'Hapus gambar latar',
            onPressed: () => setState(() {
              bg.image = null;
              bgImg = null;
            }),
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ]),
      if (bg.image != null)
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(bg.image!.split(RegExp(r'[\\/]')).last, style: grey, maxLines: 1, overflow: TextOverflow.ellipsis),
        ),
      const SizedBox(height: 12),
      Text('Jarak antar frame: ${(bg.gap * 100).toStringAsFixed(1)}%'),
      Slider(value: bg.gap, min: 0.004, max: 0.04, onChanged: (v) => setState(() => bg.gap = v)),
      Text(bg.border <= 0 ? 'Garis frame: tanpa garis' : 'Tebal garis frame: ${(bg.border * 100).toStringAsFixed(1)}%'),
      Slider(value: bg.border, min: 0, max: 0.015, onChanged: (v) => setState(() => bg.border = v)),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: false, label: Text('Garis hitam')),
          ButtonSegment(value: true, label: Text('Garis putih')),
        ],
        selected: {bg.borderWhite},
        onSelectionChanged: (v) => setState(() => bg.borderWhite = v.first),
      ),
      if (bg.image != null) ...[
        const SizedBox(height: 8),
        Text('Redupkan latar gambar: ${(bg.dim * 100).round()}%'),
        Slider(value: bg.dim, min: 0, max: 0.7, onChanged: (v) => setState(() => bg.dim = v)),
      ],
      const SizedBox(height: 12),
      const Text('Cara menampilkan foto/video di dalam frame', style: grey),
      const SizedBox(height: 8),
      SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 2, label: Text('Penuh')),
          ButtonSegment(value: 0, label: Text('Utuh')),
          ButtonSegment(value: 1, label: Text('Auto')),
          ButtonSegment(value: 3, label: Text('Utuh+blur')),
        ],
        selected: {opts.mode},
        onSelectionChanged: (v) => setState(() => opts.mode = v.first),
      ),
      const SizedBox(height: 8),
      const Text('Penuh = foto mengisi frame (dengan opsi "Sesuaikan frame" aktif, hampir tidak ada yang terpotong). Utuh = lengkap dengan bar hitam. Auto = penuh bila bentuknya mirip, selain itu utuh. Utuh+blur = lengkap, sisa ruang diisi gambar buram.', style: grey),
    ]);
  }

  Widget _panelThumb(Media m, Panel p, double s) {
    if (useBlur(opts)) {
      final b = p.box;
      final r = p.fit(m.w > 0 && m.h > 0 ? m.w / m.h : b.width / b.height);
      return Positioned(
        left: b.left * s,
        top: b.top * s,
        width: b.width * s,
        height: b.height * s,
        child: ClipRect(
          child: Stack(fit: StackFit.expand, children: [
            ImageFiltered(
              imageFilter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: _thumb(m, cover: true),
            ),
            Positioned(
              left: (r.left - b.left) * s,
              top: (r.top - b.top) * s,
              width: r.width * s,
              height: r.height * s,
              child: _thumb(m, cover: false),
            ),
          ]),
        ),
      );
    }
    if (useCover(opts, m, p)) {
      final b = p.box;
      return Positioned(
        left: b.left * s,
        top: b.top * s,
        width: b.width * s,
        height: b.height * s,
        child: ClipRect(child: _thumb(m, cover: true)),
      );
    }
    final r = p.fit(m.w > 0 && m.h > 0 ? m.w / m.h : p.box.width / p.box.height);
    return Positioned(left: r.left * s, top: r.top * s, width: r.width * s, height: r.height * s, child: _thumb(m, cover: false));
  }

  Widget _preview(List<Media> g, int fi) {
    final f = fmt!;
    final panels = comicLayout(f, g, effVariant(g, fi), bg);
    return LayoutBuilder(builder: (c, box) {
      final s = box.maxWidth / f.w;
      return ClipRect(
        child: Stack(children: [
          Positioned.fill(
            child: CustomPaint(painter: GutterPainter(f.w.toDouble(), f.h.toDouble(), const <Panel>[], bg, bgImg)),
          ),
          for (var k = 0; k < g.length && k < panels.length; k++) _panelThumb(g[k], panels[k], s),
          Positioned.fill(
            child: CustomPaint(painter: GutterPainter(f.w.toDouble(), f.h.toDouble(), panels, bg, bgImg)),
          ),
        ]),
      );
    });
  }

  // ---------- 4: suara & durasi ----------
  Widget _timeField(String label, double v, ValueChanged<double> on, String k) => TextFormField(
        key: ValueKey('$k$_rev'),
        initialValue: fmtTime(v),
        keyboardType: TextInputType.datetime,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true),
        onChanged: (t) => setState(() => on(parseTime(t, v))),
      );

  Widget _soundStep() {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Auto Duration'),
              value: auto,
              onChanged: (v) => setState(() => auto = v),
            ),
            auto
                ? _timeField('Durasi video (m:ss)', total, (v) => total = v, 'total')
                : _timeField('Durasi per foto/video (m:ss)', manualDur, (v) => manualDur = v, 'per'),
            const SizedBox(height: 8),
            Text(
              '${items.length} foto/video × ${unit.toStringAsFixed(1)} dtk + ${frames.length} jeda × ${pause.round()} dtk = ${fmtTime(unit * items.length + pause * frames.length)}. '
              'Video otomatis dipercepat/diperlambat agar pas. Di frame multi, media tampil bergantian: selesai satu, lanjut ke berikutnya (urutan baca komik: kiri-atas dulu).',
              style: grey,
            ),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Jeda antar slide: ${pause.round()} detik'),
            Slider(
              value: pause,
              min: 0,
              max: 10,
              divisions: 10,
              label: '${pause.round()} dtk',
              onChanged: (v) => setState(() => pause = v),
            ),
            const Text('Hasil akhir tiap slide ditahan selama jeda ini sebelum pindah ke slide berikutnya.', style: grey),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Kualitas hasil'),
            const SizedBox(height: 8),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Cepat')),
                ButtonSegment(value: 1, label: Text('Standar')),
                ButtonSegment(value: 2, label: Text('Tinggi')),
              ],
              selected: {opts.quality},
              onSelectionChanged: (v) => setState(() => opts.quality = v.first),
            ),
            const SizedBox(height: 8),
            const Text('Cepat = proses tercepat, resolusi lebih kecil. Tinggi = paling tajam tapi paling lama.', style: grey),
          ]),
        ),
      ),
      for (var i = 0; i < sounds.length; i++)
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              Row(children: [
                Text('Suara ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 8),
                Expanded(child: Text(sounds[i].name, maxLines: 1, overflow: TextOverflow.ellipsis, style: grey)),
                IconButton(onPressed: () => setState(() => sounds.removeAt(i)), icon: const Icon(Icons.close)),
              ]),
              const SizedBox(height: 4),
              Row(children: [
                Expanded(child: _timeField('Masuk', sounds[i].start, (v) => sounds[i].start = v, 's${sounds[i].hashCode}m')),
                const SizedBox(width: 8),
                Expanded(child: _timeField('Stop', sounds[i].stop, (v) => sounds[i].stop = v, 's${sounds[i].hashCode}s')),
              ]),
              Row(children: [
                Icon(sounds[i].volume == 0 ? Icons.volume_off : Icons.volume_up, size: 20),
                Expanded(
                  child: Slider(
                    value: sounds[i].volume,
                    min: 0,
                    max: 2,
                    divisions: 40,
                    label: '${(sounds[i].volume * 100).round()}%',
                    onChanged: (v) => setState(() => sounds[i].volume = v),
                  ),
                ),
                SizedBox(width: 48, child: Text('${(sounds[i].volume * 100).round()}%', style: grey)),
              ]),
            ]),
          ),
        ),
      OutlinedButton.icon(onPressed: addSound, icon: const Icon(Icons.add), label: const Text('Tambah Suara')),
      if (sounds.isNotEmpty)
        TextButton(
          onPressed: () => setState(() {
            total = sounds.map((s) => s.stop).reduce(max);
            _rev++;
          }),
          child: const Text('Samakan durasi video dengan akhir suara'),
        ),
    ]);
  }
}
